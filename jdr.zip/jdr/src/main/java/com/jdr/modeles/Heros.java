package com.jdr.modeles;

public class Heros extends Personnage {
	
	private String classe;
	
	public Heros() {
		
	}

	public Heros(String nom, Arme arme, int maxHp, int hp, int def, Personnage personnageOpposant) {
		super(nom, arme, maxHp, hp, def, personnageOpposant);
		
	}

	public String getClasse() {
		return classe;
	}

	public void setClasse(String classe) {
		this.classe = classe;
	}
	public String toString() {
		return getNom()+" est un(e) "+getClasse()+" avec les param�tres suivant:";
	}

	
}
