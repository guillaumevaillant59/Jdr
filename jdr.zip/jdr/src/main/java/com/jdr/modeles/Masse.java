package com.jdr.modeles;

public class Masse extends Arme {
	
	public Masse() {
				
	}
	

}
