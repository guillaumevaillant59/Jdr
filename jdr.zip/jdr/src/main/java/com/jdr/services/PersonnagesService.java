package com.jdr.services;

import java.util.List;

import com.jdr.modeles.Personnage;

public class PersonnagesService {

	public Personnage cibler(List<Personnage> liste, Personnage p) {		
		int r=(int)Math.floor (Math.random()*liste.size());	
		if(liste.size()>0) {
			p.setPersonnageOpposant(liste.get(r));
		}else {
			p.setPersonnageOpposant(null);
		}		
		return p.getPersonnageOpposant();
	}

	public String atk(List<Personnage> liste, Personnage p) {
		String s="";
		if(p.getPersonnageOpposant() != null) {
			int rdmCrit=(int)Math.floor(Math.random()*100);
			int rdmDmg;
			if(rdmCrit<=p.getArme().getCritChance()) {
				rdmDmg=(int)Math.floor(Math.random()*(p.getArme().getMaxAtk()-p.getArme().getMinAtk()))+(int)p.getArme().getMinAtk()-(int)p.getPersonnageOpposant().getDef()+10;
				p.getPersonnageOpposant().setHp(p.getPersonnageOpposant().getHp()-rdmDmg);
			}
			else {
				rdmDmg=(int)Math.floor(Math.random()*(p.getArme().getMaxAtk()-p.getArme().getMinAtk()))+(int)p.getArme().getMinAtk()-(int)p.getPersonnageOpposant().getDef();
				p.getPersonnageOpposant().setHp(p.getPersonnageOpposant().getHp()-rdmDmg);
			}
			
			if(p.getPersonnageOpposant().getHp()> 0) {
				s+=p.getNom()+" attaque "+p.getPersonnageOpposant().getNom()+" et fait "+rdmDmg+" d�gats. Il reste "+p.getPersonnageOpposant().getHp()+"PV � "+p.getPersonnageOpposant().getNom();
			}else {
				s+=p.getNom()+" attaque "+p.getPersonnageOpposant().getNom()+" et le tue.";
			}
		}
		
		return s;
	}

}
