package com.jdr.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.jdr.modeles.Arme;
import com.jdr.modeles.Combat;
import com.jdr.modeles.Epee;
import com.jdr.modeles.Masse;
import com.jdr.modeles.Monstre;
import com.jdr.modeles.Partie;
import com.jdr.modeles.Personnage;

public class PartieService {

	private Partie partie;
	List<Personnage> listeHeros = new ArrayList<Personnage>();
	List<Personnage> listeMonstres = new ArrayList<Personnage>();

	public PartieService() {

	}

	public Partie getPartie() {
		return partie;
	}

	public void setPartie(Partie partie) {
		this.partie = partie;
	}

	public void creerHeros(String nom, String classe, String arme) {
		Personnage heros;
		HerosService hs = new HerosService();
		heros = hs.defClasse(classe);
		Arme a = selectArme(arme);
		heros.setArme(a);
		heros.setNom(nom);
		listeHeros.add(heros);
		partie.setHeros(listeHeros);

	}

	public Arme selectArme(String arme) {
		Arme a = null;
		if (arme.equals("Arc")) {
			a = new Arme();
			a.setMinAtk(14);
			a.setMaxAtk(21);
			a.setCritChance(10);
		} else if (arme.equals("Epee")) {
			a = new Epee();
			a.setMinAtk(16);
			a.setMaxAtk(21);
			a.setCritChance(8);
		} else if (arme.equals("Masse")) {
			a = new Masse();
			a.setMinAtk(14);
			a.setMaxAtk(23);
			a.setCritChance(6);
		} 
		return a;
	}

	public void genererMonstre() {
		Personnage monstre = new Monstre();
		Arme a = new Arme(15, 22, 7);
		monstre.setArme(a);
		int rdmHp=(int) Math.floor(Math.random()*100)+100;
		monstre.setMaxHp(rdmHp);
		monstre.setHp(rdmHp);
		monstre.setDef(5);
		MonstresService ms = new MonstresService();
		monstre.setNom(ms.randomName());
		listeMonstres.add(monstre);
		partie.setMonstres(listeMonstres);

	}

	public void lancerPartie() {
		Scanner sc = new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		System.out.println("Bonjour, bienvenue dans mon jdr voulez vous faire une partie O/N");
		String choix0 = sc.nextLine();		
		if (choix0.equalsIgnoreCase("o")) {
			partie=new Partie();
			System.out.println("Choisie un nom de partie");
			String choix1 = sc.nextLine();
			partie.setNom(choix1);
			System.out.println("Votre partie s'appelle " + choix1);			
			int choix3 = 1;
			while (choix3 == 1) {
				System.out.println("Selectionner votre classe\n1)Archer\n2)Soigneur\n3)Guerrier\n4)Assassin");
				int choix = sc.nextInt();
				String classe = null;
				String arme = null;
				String nom = null;
				if (choix == 1) {
					classe = "Archer";
					arme = "Arc";
				} else if (choix == 2) {
					classe = "Soigneur";
					System.out.println("Choisie ton arme\n1)Epee\n2)Masse");
					int choix2 = sc.nextInt();
					if (choix2 == 1) {
						arme = "Epee";
					} else if (choix2 == 2) {
						arme = "Masse";
					}
				} else if (choix == 3) {
					classe = "Guerrier";
					System.out.println("Choisie ton arme\n1)Epee\n2)Masse");
					int choix2 = sc.nextInt();
					if (choix2 == 1) {
						arme = "Epee";
					} else if (choix2 == 2) {
						arme = "Masse";
					}
				} else if (choix == 4) {
					classe = "Assassin";
					System.out.println("Choisie ton arme\n1)Epee\n2)Masse");
					int choix2 = sc.nextInt();
					if (choix2 == 1) {
						arme = "Epee";
					} else if (choix2 == 2) {
						arme = "Masse";
					}
				}				
				System.out.println("Entre le nom de votre heros");
				nom = sc1.nextLine();
				System.out.println("Votre heros s'appelle "+nom);
				creerHeros(nom, classe, arme);
				genererMonstre();
				System.out.println("Que voulez-vous faire?\n1)Cr�er un autre personnage\n2)Lancer la partie");
				choix3 = sc.nextInt();
			}
			System.out.println("Votre �quipe se compose de :");
			for (Personnage personnage : listeHeros) {
				System.out.println(personnage.toString());
				System.out.println(personnage.getArme().toString());
			}
			sc.close();
			sc1.close();
			System.out.println("");
			Combat c=new Combat();
			c.setTourN(1);
			CombatService cs=new CombatService();
			cs.setCombat(c);
			while(c.getTourN()!=0) {				
				partie=cs.combattre(partie, c);
				cs.setTour(partie);
			}			
			for (String s : c.getTourl()) {
				System.out.println(s);
			}
			System.out.println("");
			if(partie.getHeros().isEmpty()) {
				System.out.println("Les monstres ont gagn�\n");
			}else {
				System.out.println("Les heros ont gagn�\n");
			}
			System.out.println("Merci d'avoir jouer\nA bientot");
			
		} else {
			System.out.println("Adieux");
		}

	}

}
