package com.jdr.modeles;

public class Arme {
	
	private double minAtk; 
	private double maxAtk;
	private double critChance;
	
		
	
	public Arme() {
		
	}
	
	public Arme(double minAtk, double maxAtk, double critChance) {
		super();
		this.minAtk = minAtk;
		this.maxAtk = maxAtk;
		this.critChance = critChance;
	}

	public double getMinAtk() {
		return minAtk;
	}
	public void setMinAtk(double minAtk) {
		this.minAtk = minAtk;
	}
	public double getMaxAtk() {
		return maxAtk;
	}
	public void setMaxAtk(double maxAtk) {
		this.maxAtk = maxAtk;
	}
	public double getCritChance() {
		return critChance;
	}
	public void setCritChance(double critChance) {
		this.critChance = critChance;
	}
	public String toString() {
		return "Attaque minimum : "+getMinAtk()+"\nAttaque Maximum : "+getMaxAtk()+"\nChance coup critique : "+getCritChance();
	}

}
