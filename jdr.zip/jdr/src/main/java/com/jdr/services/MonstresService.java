package com.jdr.services;

public class MonstresService {
	
	public String randomName() {
		 String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; // Tu supprimes les lettres dont tu ne veux pas
		    String nom = "";
		    int longeur=(int)Math.floor(Math.random() * 10)+1;
		    for(int i=0;i<longeur;i++)
		    {
		       int x = (int)Math.floor(Math.random() * 52); // Si tu supprimes des lettres tu diminues ce nb
		       nom += chars.charAt(x);
		    }		    
		    return nom;
	}

}
