package com.jdr.modeles;

public class Epee extends Arme{

	public Epee() {
		
		
	}
	
	

}
