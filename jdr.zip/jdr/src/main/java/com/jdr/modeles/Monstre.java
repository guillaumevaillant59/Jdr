package com.jdr.modeles;

public class Monstre extends Personnage {
	
	public Monstre() {
		
	}

	public Monstre(String nom, Arme arme, int maxHp, int hp, int def, Personnage personnageOpposant,
			Personnage personnageAttaquant) {
		super(nom, arme, maxHp, hp, def, personnageOpposant);
		
	}
	
	

}
