package com.jdr.modeles;

import java.util.List;

public class Partie {
	
	String nom;
	List<Personnage> monstres;
	List<Personnage> heros;
	
	
	
	public Partie() {
		
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public List<Personnage> getMonstres() {
		return monstres;
	}
	public void setMonstres(List<Personnage> monstres) {
		this.monstres = monstres;
	}
	public List<Personnage> getHeros() {
		return heros;
	}
	public void setHeros(List<Personnage> heros) {
		this.heros = heros;
	}
	
	

}
