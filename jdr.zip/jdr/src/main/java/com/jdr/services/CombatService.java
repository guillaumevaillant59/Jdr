package com.jdr.services;

import java.util.ArrayList;
import java.util.List;

import com.jdr.modeles.Combat;
import com.jdr.modeles.Heros;
import com.jdr.modeles.Partie;
import com.jdr.modeles.Personnage;

public class CombatService {

	private Combat combat;
	List<String> liste = new ArrayList<String>();

	public CombatService() {

	}

	public Combat getCombat() {
		return combat;
	}

	public void setCombat(Combat combat) {
		this.combat = combat;
	}

	public int getTour() {
		int n = combat.getTourN();
		return n;
	}

	public void setTour(Partie p) {
		if (p.getHeros().isEmpty() || p.getMonstres().isEmpty()) {
			combat.setTourN(0);
		} else {
			combat.setTourN(getTour() + 1);
		}

	}

	public Partie combattre(Partie p, Combat c) {
		String s = "---------" + c.getTourN() + " �me manche-------\n\n";
		int rdm = (int) Math.floor(Math.random() * 100);
		PersonnagesService ps = new PersonnagesService();
		HerosService hs = new HerosService();
		if (rdm >= 50) {
			for (Personnage personnage : p.getHeros()) {
				Heros heros = (Heros) personnage;
				if (heros.getClasse().equals("Soigneur")) {
					int rdms = (int) Math.floor(Math.random() * 100);
					if (rdms <= 20) {
						Personnage heale = hs.heal(p.getHeros());
						if (heale.getHp() < heale.getMaxHp()) {
							heale.setHp(heale.getMaxHp());
							s += heros.getNom() + " soigne " + heale.getNom() + "\n";
						} else {
							ps.cibler(p.getMonstres(), heros);
							String attaque = ps.atk(p.getMonstres(), heros);
							s += attaque + "\n";
							ramasserTesMorts(p);
						}

					} else {
						ps.cibler(p.getMonstres(), heros);
						String attaque = ps.atk(p.getMonstres(), heros);
						s += attaque + "\n";
						ramasserTesMorts(p);
					}

				} else {
					ps.cibler(p.getMonstres(), heros);
					String attaque = ps.atk(p.getMonstres(), heros);
					s += attaque + "\n";
					ramasserTesMorts(p);
				}

			}
			for (Personnage personnage : p.getMonstres()) {
				Heros heros = (Heros) ps.cibler(p.getHeros(), personnage);
				if (heros != null) {
					if (heros.getClasse().equals("Guerrier")) {
						int rdmb = (int) Math.floor(Math.random() * 100);
						if (rdmb <= 10) {
							s += heros.getNom() + " bloque l'attaque de " + personnage.getNom() + "\n";
						} else {
							String attaque = ps.atk(p.getHeros(), personnage);
							s += attaque + "\n";
							ramasserTesMorts(p);
						}
					} else if (heros.getClasse().equals("Assassin")) {
						int rdmb = (int) Math.floor(Math.random() * 100);
						if (rdmb <= 30) {
							s += heros.getNom() + " esquive l'attaque de" + personnage.getNom() + "\n";
						} else {
							String attaque = ps.atk(p.getHeros(), personnage);
							s += attaque + "\n";
							ramasserTesMorts(p);
						}
					} else {
						String attaque = ps.atk(p.getHeros(), personnage);
						s += attaque + "\n";
						ramasserTesMorts(p);
					}
				}
			}

		} else {
			for (Personnage personnage : p.getMonstres()) {
				Heros heros = (Heros) ps.cibler(p.getHeros(), personnage);
				if (heros != null) {
					if (heros.getClasse().equals("Guerrier")) {
						int rdmb = (int) Math.floor(Math.random() * 100);
						if (rdmb <= 10) {
							s += heros.getNom() + " bloque l'attaque de " + personnage.getNom() + "\n";
						} else {
							String attaque = ps.atk(p.getHeros(), personnage);
							s += attaque + "\n";
							ramasserTesMorts(p);
						}
					} else if (heros.getClasse().equals("Assassin")) {
						int rdmb = (int) Math.floor(Math.random() * 100);
						if (rdmb <= 30) {
							s += heros.getNom() + " esquive l'attaque de " + personnage.getNom() + "\n";
						} else {
							String attaque = ps.atk(p.getHeros(), personnage);
							s += attaque + "\n";
							ramasserTesMorts(p);
						}
					} else {
						String attaque = ps.atk(p.getHeros(), personnage);
						s += attaque + "\n";
						ramasserTesMorts(p);
					}
				}
			}

			for (Personnage personnage : p.getHeros()) {
				Heros heros = (Heros) personnage;
				if (heros.getClasse().equals("Soigneur")) {
					int rdms = (int) Math.floor(Math.random() * 100);
					if (rdms <= 20) {
						Personnage heale = hs.heal(p.getHeros());
						if (heale.getHp() < heale.getMaxHp()) {
							heale.setHp(heale.getMaxHp());
							s += heros.getNom() + " soigne " + heale.getNom() + "\n";
						} else {
							ps.cibler(p.getMonstres(), heros);
							String attaque = ps.atk(p.getMonstres(), heros);
							s += attaque + "\n";
							ramasserTesMorts(p);
						}
					} else {
						ps.cibler(p.getMonstres(), heros);
						String attaque = ps.atk(p.getMonstres(), heros);
						s += attaque + "\n";
						ramasserTesMorts(p);
					}
				} else {
					ps.cibler(p.getMonstres(), heros);
					String attaque = ps.atk(p.getMonstres(), heros);
					s += attaque + "\n";
					ramasserTesMorts(p);
				}
			}

		}

		liste = combat.getTourl();
		liste.add(s);
		combat.setTourl(liste);
		return p;

	}

	public void ramasserTesMorts(Partie p) {
		for (int i = p.getHeros().size() - 1; i >= 0; i--) {
			if (p.getHeros().get(i).getHp() < 0) {
				p.getHeros().remove(i);
			}
		}
		for (int i = p.getMonstres().size() - 1; i >= 0; i--) {
			if (p.getMonstres().get(i).getHp() < 0) {
				p.getMonstres().remove(i);
			}
		}
	}

}
