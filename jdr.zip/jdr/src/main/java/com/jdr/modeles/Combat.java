package com.jdr.modeles;

import java.util.ArrayList;
import java.util.List;

public class Combat {
	
	private int tourN;
	private List<String> tourl;
	
	public Combat() {
		this.tourl=new ArrayList<String>();
	}

	public int getTourN() {
		return tourN;
	}

	public void setTourN(int tourN) {
		this.tourN = tourN;
	}

	public List<String> getTourl() {
		return tourl;
	}

	public void setTourl(List<String> tourl) {
		this.tourl = tourl;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Combat [tourN=");
		builder.append(tourN);
		builder.append(", tourl=");
		builder.append(tourl);
		builder.append("]");
		return builder.toString();
	}

	
	
	
	
	

}
