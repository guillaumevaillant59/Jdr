package com.jdr.services;

import java.util.List;

import com.jdr.modeles.Heros;
import com.jdr.modeles.Personnage;

public class HerosService {
	
	public Personnage defClasse(String classe) {
		Heros heros=new Heros();
		if(classe.equals("Archer")) {
			heros.setClasse(classe);
			heros.setMaxHp(100);
			heros.setHp(100);
			heros.setDef(4);
		}else if(classe.equals("Soigneur")) {
			heros.setClasse(classe);
			heros.setMaxHp(100);
			heros.setHp(100);
			heros.setDef(3);
		}else if(classe.equals("Guerrier")) {
			heros.setClasse(classe);
			heros.setMaxHp(100);
			heros.setHp(100);
			heros.setDef(6);
		}else if(classe.equals("Assassin")) {
			heros.setClasse(classe);
			heros.setMaxHp(100);
			heros.setHp(100);
			heros.setDef(5);
		}
		return heros;
	}
	
	public Personnage heal(List<Personnage> herosListe) {
		int faible=0;
		int hpf=100;
		for (int i = 0; i < herosListe.size(); i++) {
			if(herosListe.get(i).getHp()<hpf&&herosListe.get(i).getHp()<herosListe.get(i).getMaxHp()) {
				hpf=herosListe.get(i).getHp();
				faible=i;
			}			
		}
		Heros heros=(Heros) herosListe.get(faible);
		return heros;
		
	}

}
