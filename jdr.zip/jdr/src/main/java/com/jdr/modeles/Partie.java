package com.jdr.modeles;

import java.util.ArrayList;
import java.util.List;

public class Partie {
	
	String nom;
	List<Personnage> monstres;
	List<Personnage> heros;
	
	
	
	public Partie() {
		this.monstres=new ArrayList<Personnage>();
		this.heros=new ArrayList<Personnage>();
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public List<Personnage> getMonstres() {
		return monstres;
	}
	public void setMonstres(List<Personnage> monstres) {
		this.monstres = monstres;
	}
	public List<Personnage> getHeros() {
		return heros;
	}
	public void setHeros(List<Personnage> heros) {
		this.heros = heros;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Partie [nom=");
		builder.append(nom);
		builder.append(", monstres=");
		builder.append(monstres);
		builder.append(", heros=");
		builder.append(heros);
		builder.append("]");
		return builder.toString();
	}
	
	
	

}
