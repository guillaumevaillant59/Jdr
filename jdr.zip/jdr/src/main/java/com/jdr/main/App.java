package com.jdr.main;

import com.jdr.services.PartieService;

public class App {
	
	public static void main(String[] args) {
		PartieService ps=new PartieService();
		ps.lancerPartie();
		
	}

}
